package com.atm.transaction;

import com.atm.model.Account;
import java.util.Scanner;

public class Withdrawal extends Transaction {
   public Withdrawal(Account account) {
      super(account);
   }

   public void execute() {
      Scanner scanner = new Scanner(System.in);
      System.out.print("Masukkan jumlah penarikan: ");
      double amount = scanner.nextDouble();

      if (amount > this.account.getBalance()) {
         System.out.println("Saldo tidak mencukupi.");
      } else if (!this.account.canWithdraw(amount)) {
         System.out.println("Penarikan gagal. Saldo harus tersisa minimal Rp50,000.");
      } else {
         this.account.debit(amount);
         System.out.println("Penarikan berhasil. Saldo Anda sekarang: " + this.account.getBalance());
      }
   }
}
